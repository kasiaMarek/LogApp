package com.example.myapplication.model

class Task(
    var task_id: String,
    var title: String,
    var date: String,
    var hour: String,
    var time_spent: String,
    var status:String

)